from sqlalchemy.orm import Session

from models import Series


def create_series(db: Session, title: str, genre: str, seasons: int) -> Series:
    series = Series(title=title, genre=genre, seasons=seasons)
    db.add(series)
    db.commit()
    db.refresh(series)  # carrega o id gerado pelo banco
    return series


def list_series(db: Session) -> list[Series]:
    return db.query(Series).order_by(Series.id).all()


def get_series(db: Session, series_id: int) -> Series | None:
    return db.get(Series, series_id)


def update_series(
    db: Session,
    series_id: int,
    title: str | None = None,
    genre: str | None = None,
    seasons: int | None = None,
) -> Series | None:
    series = get_series(db, series_id)
    if series is None:
        return None

    if title is not None:
        series.title = title
    if genre is not None:
        series.genre = genre
    if seasons is not None:
        series.seasons = seasons

    db.commit()
    db.refresh(series)
    return series


def delete_series(db: Session, series_id: int) -> bool:
    series = get_series(db, series_id)
    if series is None:
        return False

    db.delete(series)
    db.commit()
    return True
