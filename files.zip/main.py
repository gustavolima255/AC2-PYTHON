import crud
from database import Base, SessionLocal, engine
import models  # noqa: F401  (garante que Series seja registrada em Base)


def print_all(db):
    for s in crud.list_series(db):
        print(f"  {s}")


def main():
    # Recria as tabelas para a demonstração ser repetível.
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    try:
        print("=== CREATE ===")
        s1 = crud.create_series(db, "Breaking Bad", "Drama", 5)
        s2 = crud.create_series(db, "Dark", "Ficção científica", 3)
        s3 = crud.create_series(db, "The Office", "Comédia", 9)
        for s in (s1, s2, s3):
            print(f"  Criada: {s}")

        print("\n=== READ ===")
        print_all(db)

        print("\n=== READ BY ID ===")
        found = crud.get_series(db, s2.id)
        print(f"  Série com id={s2.id}: {found}")

        print("\n=== UPDATE ===")
        updated = crud.update_series(db, s3.id, seasons=10, genre="Comédia/Sitcom")
        print(f"  Atualizada: {updated}")

        print("\n=== DELETE ===")
        removed = crud.delete_series(db, s1.id)
        print(f"  Série id={s1.id} removida? {removed}")

        print("\n=== READ FINAL ===")
        print_all(db)
    finally:
        db.close()


if __name__ == "__main__":
    main()
