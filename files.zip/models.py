from sqlalchemy import Column, Integer, String

from database import Base


class Series(Base):
    __tablename__ = "series"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    genre = Column(String, nullable=False)
    seasons = Column(Integer, nullable=False, default=1)

    def __repr__(self):
        return (
            f"Series(id={self.id}, title={self.title!r}, "
            f"genre={self.genre!r}, seasons={self.seasons})"
        )
